mutable struct KronMatrix2
    a::Vector{Matrix}  # store matrices A{i}
    b::Vector{Matrix}  # store matrices B{i}

    # No-arg constructor: empty KronMatrix
    KronMatrix2() = new(Matrix[], Matrix[])

    # Single-arg constructor: copy if kronMatrix else error
    KronMatrix2(G::KronMatrix2) = new(copy(G.a), copy(G.b))

    # Two-arg constructor: if both matrices, wrap in vectors
    KronMatrix2(A::AbstractMatrix, B::AbstractMatrix) = new([A], [B])

end
